from setuptools import setup

setup (

    name="entrega2",
    version = "1.0",
    description = "Estamos haciendo el primer paquete",
    author = "Juanse Cortes",
    author_email="juanc183.jc@gmail.com",

    packages = ["entrega2"]

)

# python setup.py sdist
# cd dist
# pip install nombrepaquete